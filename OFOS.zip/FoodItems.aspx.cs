﻿using System;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OFOS
{
    public partial class FoodItems : System.Web.UI.Page
    {
        string constr = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\sadsa\Documents\MWM\OSOF\Online-Food-Ordering-System-master\App_Data\ofos.mdf;Integrated Security=True";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["user"] == null)
                {
                    sizlr.Visible = true;
                    sizlr.Text = "Sizzlers Are Not Available For ONLINE ORDER";
                    hl.Visible = true;
                    Register.Visible = true;
                    b.Visible = false;
                    b1.Visible = false;
                }
                else
                {
                    my_order.Visible = true;
                    hl.Visible = false;
                    u.Text = Session["user"].ToString();
                    Label1.Text = u.Text;

                    if (Session["user"].ToString() == "Guest")
                    {
                        b.Visible = false;
                        b1.Visible = true;
                        Label1.Visible = true;
                        Label2.Visible = true;
                    }
                    else
                    {
                        b.Visible = true;
                        b1.Visible = false;
                        dropdown.Visible = true;
                    }
                }
            }
        }

        protected void LogOut_click(object sender, EventArgs e)
        {
            Session.Abandon();
            Session.Clear();
            Response.Redirect("~/FoodItems.aspx");
        }

        protected void signin_click(object sender, EventArgs e)
        {
            Response.Redirect("~/Login.aspx");
        }

        protected void Register_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Registration.aspx");
        }

        protected void Button_soup_onclick(object sender, EventArgs e)
        {
            LoadItemsByType("SOUPS");
        }

        protected void Button_starter_onclick(object sender, EventArgs e)
        {
            LoadItemsByType("STARTERS");
        }

        protected void Button_rice_onclick(object sender, EventArgs e)
        {
            LoadItemsByType("RICE");
        }

        protected void Button_noodles_onclick(object sender, EventArgs e)
        {
            LoadItemsByType("NOODLES");
        }

        protected void Button_maincourse_onclick(object sender, EventArgs e)
        {
            LoadItemsByType("MAIN COURSE");
        }

        protected void Button_dessert_onclick(object sender, EventArgs e)
        {
            LoadItemsByType("DESSERTS");
        }

        private void LoadItemsByType(string itemType)
        {
            pic.Visible = false;

            using (SqlConnection con = new SqlConnection(constr))
            {
                try
                {
                    con.Open();
                    string selectSQL = "SELECT Item_no, Item_name, Description, Image_url, Price FROM [dbo].[Item_Master] WHERE Type = @Type";
                    SqlCommand cmd = new SqlCommand(selectSQL, con);
                    cmd.Parameters.AddWithValue("@Type", itemType);

                    griditem.DataSource = cmd.ExecuteReader();
                    griditem.DataBind();
                }
                catch (Exception err)
                {
                    status.Text = "Error loading items: " + err.Message;
                    status.Visible = true;
                }
            }
        }

        protected void griditem_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "AddToCart")
            {
                try
                {
                    GridViewRow gvr = (GridViewRow)((Control)e.CommandSource).NamingContainer;
                    TextBox temp = (TextBox)gvr.FindControl("tb_quantity");

                    int quantity;
                    if (temp != null && int.TryParse(temp.Text, out quantity) && quantity >= 1 && quantity <= 10)
                    {
                        AddToCart(gvr, quantity);
                    }
                    else
                    {
                        status.Text = "Invalid quantity entered. Please enter a value between 1 and 10.";
                        status.Visible = true;
                    }
                }
                catch (Exception ex)
                {
                    status.Text = "An error occurred: " + ex.Message;
                    status.Visible = true;
                }
            }
        }

        private void AddToCart(GridViewRow gvr, int quantity)
        {
            if (Session["customer_id"] == null)
            {
                status.Text = "Please log in first to add items to your cart.";
                status.Visible = true;
                return;
            }

            using (SqlConnection con = new SqlConnection(constr))
            {
                try
                {
                    con.Open();

                    if (Session["order_id"] == null)
                    {
                        string inSQL = "INSERT INTO [dbo].[Orders] (Cust_Id, Status_Id, Date) VALUES(@id, @status, @date)";
                        SqlCommand cmd = new SqlCommand(inSQL, con);
                        cmd.Parameters.AddWithValue("@id", (int)Session["customer_id"]);
                        cmd.Parameters.AddWithValue("@status", 1); // Assuming 1 is 'Pending'
                        cmd.Parameters.AddWithValue("@date", DateTime.Now);
                        cmd.ExecuteNonQuery();

                        string selectSQL = "SELECT MAX(Order_Id) FROM [dbo].[Orders]";
                        cmd = new SqlCommand(selectSQL, con);
                        int orderId = (int)cmd.ExecuteScalar();
                        Session["order_id"] = orderId;
                        my_order.Visible = true;
                    }

                    int itemNo = Convert.ToInt32(gvr.Cells[0].Text);
                    string checkSQL = "SELECT COUNT(*) FROM [dbo].[Order_Details] WHERE Order_Id = @id AND Item_no = @item";
                    SqlCommand checkCmd = new SqlCommand(checkSQL, con);
                    checkCmd.Parameters.AddWithValue("@id", (int)Session["order_id"]);
                    checkCmd.Parameters.AddWithValue("@item", itemNo);

                    int exist = (int)checkCmd.ExecuteScalar();

                    if (exist > 0)
                    {
                        string updateSQL = "UPDATE [dbo].[Order_Details] SET Quantity = Quantity + @value, Amount = (Quantity + @value) * Price WHERE Order_Id = @id AND Item_no = @item";
                        SqlCommand updateCmd = new SqlCommand(updateSQL, con);
                        updateCmd.Parameters.AddWithValue("@value", quantity);
                        updateCmd.Parameters.AddWithValue("@id", (int)Session["order_id"]);
                        updateCmd.Parameters.AddWithValue("@item", itemNo);
                        updateCmd.ExecuteNonQuery();
                    }
                    else
                    {
                        string insertSQL = "INSERT INTO [dbo].[Order_Details] (Order_Id, Item_no, Quantity, Price, Amount) VALUES(@order_id, @item_no, @qty, @price, @amount)";
                        SqlCommand insertCmd = new SqlCommand(insertSQL, con);
                        insertCmd.Parameters.AddWithValue("@order_id", (int)Session["order_id"]);
                        insertCmd.Parameters.AddWithValue("@item_no", itemNo);
                        insertCmd.Parameters.AddWithValue("@qty", quantity);
                        insertCmd.Parameters.AddWithValue("@price", Convert.ToDecimal(gvr.Cells[4].Text));
                        insertCmd.Parameters.AddWithValue("@amount", quantity * Convert.ToDecimal(gvr.Cells[4].Text));
                        insertCmd.ExecuteNonQuery();
                    }

                    Button b = (Button)gvr.FindControl("button_cart");
                    b.Visible = false;
                    Label l = (Label)gvr.FindControl("l1");
                    l.Visible = true;
                    TextBox temp = (TextBox)gvr.FindControl("tb_quantity");
                    temp.Enabled = false;
                }
                catch (Exception err)
                {
                    status.Text = "An error occurred: " + err.Message;
                    status.Visible = true;
                }
            }
        }

        protected void MyOrder_click(object sender, EventArgs e)
        {
            Response.Redirect("~/MyOrder.aspx");
        }
    }
}
