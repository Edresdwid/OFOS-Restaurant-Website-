﻿using System;
using System.Data.SqlClient;

namespace OFOS
{
    public partial class Login : System.Web.UI.Page
    {
        private readonly string constr = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\sadsa\Documents\MWM\OSOF\Online-Food-Ordering-System-master\App_Data\ofos.mdf;Integrated Security=True";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                status0.Text = Request.QueryString["msg"];
            }
        }

        protected void Login_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(constr))
            {
                string selectSQL = "SELECT * FROM [dbo].[Customers] WHERE Username=@username AND Password=@password";
                SqlCommand cmd = new SqlCommand(selectSQL, con);

                cmd.Parameters.AddWithValue("@username", tb_user.Text);
                cmd.Parameters.AddWithValue("@password", tb_pwd.Text);

                try
                {
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    if (!reader.HasRows)
                    {
                        status.Text = "Invalid Username or Password.";
                    }
                    else
                    {
                        reader.Read();
                        Session["customer_id"] = reader["Cust_Id"];
                        Session["user"] = tb_user.Text;
                        Response.Redirect("~/FoodItems.aspx");
                    }
                }
                catch (Exception ex)
                {
                    status.Text = "An error occurred: " + ex.Message;
                }
            }
        }


        protected void user_click(object sender, EventArgs e)
        {
            registered.Visible = true;
            guest.Visible = false;
        }

        protected void guest_click(object sender, EventArgs e)
        {
            registered.Visible = false;
            guest.Visible = true;
        }

        protected void Button1_register_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(constr))
            {
                string insertSQL = "INSERT INTO [dbo].[Customers] (Name, Username, Email, Contact_No, House_No, Street, City) VALUES (@Name, @username, @Email, @Contact_No, @House_No, @Street, @City)";
                SqlCommand cmd = new SqlCommand(insertSQL, con);

                cmd.Parameters.AddWithValue("@Name", tb_name.Text);
                cmd.Parameters.AddWithValue("@username", "Guest" + DateTime.Now.ToString("yyyyMMddHHmmss"));
                cmd.Parameters.AddWithValue("@Email", tb_email.Text);
                cmd.Parameters.AddWithValue("@Contact_No", tb_contact.Text);
                cmd.Parameters.AddWithValue("@House_No", tb_house.Text);
                cmd.Parameters.AddWithValue("@Street", tb_street.Text);
                cmd.Parameters.AddWithValue("@City", DropDownList1_city.SelectedValue);

                try
                {
                    con.Open();
                    cmd.ExecuteNonQuery();

                    cmd.CommandText = "SELECT MAX(Cust_Id) FROM [dbo].[Customers]";
                    Session["customer_id"] = (int)cmd.ExecuteScalar();
                    Session["user"] = "Guest";
                    Response.Redirect("~/FoodItems.aspx");
                }
                catch (Exception ex)
                {
                    status.Text = "An error occurred: " + ex.Message;
                }
            }
        }
    }
}
