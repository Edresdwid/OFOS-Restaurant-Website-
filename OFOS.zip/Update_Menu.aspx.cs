﻿using System;
using System.Data.SqlClient;
using System.Web.UI;

namespace OFOS
{
    public partial class Update_Menu : Page
    {
        string constr = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\sadsa\Documents\MWM\OSOF\Online-Food-Ordering-System-master\App_Data\ofos.mdf;Integrated Security=True";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["admin"] == null)
            {
                Response.Redirect("Admin_Login.aspx?You need to login first");
            }
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            Session["admin"] = null;
            Response.Redirect("Admin_Login.aspx");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("Add_items.aspx");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("Modify.aspx");
        }

        protected void btnAddCategory_Click(object sender, EventArgs e)
        {
            string categoryName = txtCategoryName.Text.Trim();

            if (!string.IsNullOrEmpty(categoryName))
            {
                using (SqlConnection con = new SqlConnection(constr))
                {
                    try
                    {
                        con.Open();
                        string insertSQL = "INSERT INTO [dbo].[Food_Categories] (Category_Name) VALUES (@CategoryName)";
                        SqlCommand cmd = new SqlCommand(insertSQL, con);
                        cmd.Parameters.AddWithValue("@CategoryName", categoryName);
                        cmd.ExecuteNonQuery();

                        // Optionally clear the TextBox
                        txtCategoryName.Text = string.Empty;
                        Response.Write("<script>alert('Category added successfully!');</script>");
                    }
                    catch (Exception ex)
                    {
                        Response.Write("<script>alert('Error adding category: " + ex.Message + "');</script>");
                    }
                }
            }
            else
            {
                Response.Write("<script>alert('Please enter a category name.');</script>");
            }
        }
    }
}
