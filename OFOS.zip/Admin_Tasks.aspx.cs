﻿using System;
using System.Web.UI;

namespace OFOS
{
    public partial class Admin_tasks : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["admin"] == null)
                {
                    Response.Redirect("Admin_Login.aspx?msg=You need to login first");
                }
                else
                {
                    Label1.Text = "Hello, " + Session["admin"].ToString();
                }
            }
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            Session["admin"] = null;
            Response.Redirect("Admin_Login.aspx");
        }
    }
}
