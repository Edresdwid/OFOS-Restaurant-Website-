﻿using System;
using System.Web.UI;
using System.Data.SqlClient;

namespace OFOS
{
    public partial class Feedback : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] == null)
            {
                Response.Redirect("FoodItems.aspx");
            }
            else
            {
                l2.Visible = true;
                l.Text = Session["user"].ToString();
            }
        }

        protected void LogOut_click(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("~/FoodItems.aspx");
        }

        protected void Btn1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(tb_fd.Text))
            {
                Lbl_status.Visible = true;
                Lbl_status.Text = "Please provide feedback.";
            }
            else
            {
                string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\sadsa\Documents\MWM\OSOF\Online-Food-Ordering-System-master\App_Data\ofos.mdf;Integrated Security=True";
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    try
                    {
                        con.Open();
                        string insertSQL = "INSERT INTO [dbo].[Feedback] (Cust_Id, Username, Comment) VALUES (@Cust_Id, @Username, @Comment)";

                        SqlCommand cmd = new SqlCommand(insertSQL, con);
                        cmd.Parameters.AddWithValue("@Cust_Id", (int)Session["customer_id"]);
                        cmd.Parameters.AddWithValue("@Username", Session["user"].ToString());
                        cmd.Parameters.AddWithValue("@Comment", tb_fd.Text);

                        cmd.ExecuteNonQuery();

                        Lbl_status.Visible = true;
                        Lbl_status.Text = "Your feedback has been submitted.";
                        Btn1.Visible = false;
                    }
                    catch (Exception err)
                    {
                        Lbl_status.Visible = true;
                        Lbl_status.Text = "Error: " + err.Message;
                    }
                }
            }
        }

        protected void Home_click(object sender, EventArgs e)
        {
            Response.Redirect("FoodItems.aspx");
        }
    }
}
