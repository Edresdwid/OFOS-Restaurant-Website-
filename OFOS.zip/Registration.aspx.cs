﻿using System;
using System.Data.SqlClient;

namespace OFOS
{
    public partial class Registration : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Page Load logic can be added here if needed
        }

        protected void Button1_register_Click(object sender, EventArgs e)
        {
            string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\sadsa\Documents\MWM\OSOF\Online-Food-Ordering-System-master\App_Data\ofos.mdf;Integrated Security=True;Max Pool Size=100;";
            SqlConnection con = new SqlConnection(connectionString);

            try
            {
                con.Open();

                // Check if the username already exists
                string checkUserQuery = "SELECT COUNT(*) FROM [dbo].[Customers] WHERE Username = @Username";
                SqlCommand checkUserCmd = new SqlCommand(checkUserQuery, con);
                checkUserCmd.Parameters.AddWithValue("@Username", tb_username.Text);

                int userExists = (int)checkUserCmd.ExecuteScalar();
                if (userExists > 0)
                {
                    lblStatus.Text = "Username already exists. Please choose another one.";
                    return;
                }

                // Insert new user data
                string insertQuery = @"INSERT INTO [dbo].[Customers] 
                                       (Name, Username, Password, Email, Contact_No, House_No, Street, City) 
                                       VALUES 
                                       (@Name, @Username, @Password, @Email, @Contact_No, @House_No, @Street, @City)";
                SqlCommand insertCmd = new SqlCommand(insertQuery, con);

                insertCmd.Parameters.AddWithValue("@Name", tb_name.Text);
                insertCmd.Parameters.AddWithValue("@Username", tb_username.Text);
                insertCmd.Parameters.AddWithValue("@Password", tb_pwd.Text);
                insertCmd.Parameters.AddWithValue("@Email", tb_email.Text);
                insertCmd.Parameters.AddWithValue("@Contact_No", tb_contact.Text);
                insertCmd.Parameters.AddWithValue("@House_No", tb_house.Text);
                insertCmd.Parameters.AddWithValue("@Street", tb_street.Text);
                insertCmd.Parameters.AddWithValue("@City", DropDownList1_city.SelectedItem.Text);

                int rowsAffected = insertCmd.ExecuteNonQuery();

                if (rowsAffected > 0)
                {
                    lblStatus.Text = "Registration successful.";
                }
                else
                {
                    lblStatus.Text = "Registration failed. Please try again.";
                }
            }
            catch (Exception ex)
            {
                lblStatus.Text = "An error occurred: " + ex.Message;
            }
            finally
            {
                con.Close();
            }
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            Response.Redirect("FoodItems.aspx");
        }
    }
}
