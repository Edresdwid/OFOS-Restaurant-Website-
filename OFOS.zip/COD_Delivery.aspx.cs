﻿using System;
using System.Web.UI;
using System.Data.SqlClient;

namespace OFOS
{
    public partial class COD : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["order_id"] == null)
            {
                Response.Redirect("FoodItems.aspx");
            }
            else if (Session["pay"] == null)
            {
                Response.Redirect("MyOrder.aspx?msg=Payment mode needs to be selected");
            }

            if (Session["user"] == null)
            {
                b.Visible = false;
            }
            else
            {
                l2.Visible = true;
                l.Text = Session["user"].ToString();
                b1.Visible = Session["user"].ToString() == "Guest";
                b.Visible = !b1.Visible;
            }

            if (!IsPostBack)
            {
                if (Session["pay"].ToString() == "OT")
                {
                    Label1.Text = $"Transaction successful!<br/>Payment of ₹{Session["total"]} received.<br/><br/>Please provide Delivery details.";
                }
                else if (Session["pay"].ToString() == "COD")
                {
                    Label1.Text = "Please provide Delivery details.";
                }

                LoadCustomerDetails();
            }
        }

        private void LoadCustomerDetails()
        {
            string constr = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\sadsa\Documents\MWM\OSOF\Online-Food-Ordering-System-master\App_Data\ofos.mdf;Integrated Security=True";
            string query = "SELECT Name, House_no, Street, City, Contact_No FROM [dbo].[Customers] WHERE Cust_Id=@Cust_Id";
            using (SqlConnection con = new SqlConnection(constr))
            {
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@Cust_Id", Session["customer_id"]);

                try
                {
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.Read())
                    {
                        Name.Text = reader["Name"].ToString();
                        House_no.Text = reader["House_no"].ToString();
                        Street.Text = reader["Street"].ToString();
                        D_city.SelectedValue = reader["City"].ToString();
                        Contact.Text = reader["Contact_No"].ToString();
                    }
                }
                catch (Exception err)
                {
                    Label1.Text = "Error: " + err.Message;
                }
            }
        }

        protected void LogOut_click(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("~/FoodItems.aspx");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            string constr = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\sadsa\Documents\MWM\OSOF\Online-Food-Ordering-System-master\App_Data\ofos.mdf;Integrated Security=True";
            using (SqlConnection con = new SqlConnection(constr))
            {
                string query = "INSERT INTO [dbo].[Delivery] (Order_Id, Name, House_no, Street, City, Contact_no) VALUES (@Order_Id, @Name, @House_no, @Street, @City, @Contact_No)";
                SqlCommand cmd = new SqlCommand(query, con);

                cmd.Parameters.AddWithValue("@Order_Id", Session["order_id"]);
                cmd.Parameters.AddWithValue("@Name", Name.Text);
                cmd.Parameters.AddWithValue("@House_no", House_no.Text);
                cmd.Parameters.AddWithValue("@Street", Street.Text);
                cmd.Parameters.AddWithValue("@City", D_city.SelectedValue);
                cmd.Parameters.AddWithValue("@Contact_No", Contact.Text);

                try
                {
                    con.Open();
                    cmd.ExecuteNonQuery();

                    if (Session["pay"].ToString() == "COD")
                    {
                        UpdateOrderStatus(con);
                        InsertPaymentDetails(con);
                    }

                    Response.Redirect("Final.aspx");
                }
                catch (Exception err)
                {
                    Label1.Text = "Error: " + err.Message;
                }
            }
        }

        private void UpdateOrderStatus(SqlConnection con)
        {
            string query = "UPDATE [dbo].[Orders] SET Status_Id=1, Date=@Date WHERE Order_Id=@Order_Id"; // Changed Status to Status_Id
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@Order_Id", Session["order_id"]);
            cmd.Parameters.AddWithValue("@Date", DateTime.Now);

            cmd.ExecuteNonQuery();
        }

        private void InsertPaymentDetails(SqlConnection con)
        {
            string query = "INSERT INTO [dbo].[Payment] (Order_Id, Mode, COD_Pay_Status) VALUES (@Order_Id, @Mode, @COD_Pay_Status)";
            SqlCommand cmd = new SqlCommand(query, con);

            cmd.Parameters.AddWithValue("@Order_Id", Session["order_id"]);
            cmd.Parameters.AddWithValue("@Mode", "COD");
            cmd.Parameters.AddWithValue("@COD_Pay_Status", "Pending");

            cmd.ExecuteNonQuery();
        }
    }
}
