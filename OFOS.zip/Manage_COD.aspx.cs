﻿using System;
using System.Data.SqlClient;

namespace OFOS
{
    public partial class Manage_COD : System.Web.UI.Page
    {
        private readonly string conStrng = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\sadsa\Documents\MWM\OSOF\Online-Food-Ordering-System-master\App_Data\ofos.mdf;Integrated Security=True";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["admin"] == null)
            {
                Response.Redirect("Admin_Login.aspx?msg=You need to login first");
            }
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            Session["admin"] = null;
            Response.Redirect("Admin_Login.aspx");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(conStrng))
            {
                try
                {
                    con.Open();
                    string query = "SELECT COD_Pay_Status FROM [dbo].[Payment] WHERE Order_Id=@order_id";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@order_id", TextBox1.Text);

                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.Read())
                    {
                        if (reader["COD_Pay_Status"].ToString() == "Received")
                        {
                            Label1.Text = $"<h5>Status for Order ID {TextBox1.Text} is already updated.</h5>";
                        }
                        else
                        {
                            reader.Close();
                            UpdateOrderStatus(con);
                        }
                    }
                    else
                    {
                        Label1.Text = $"<h5>Invalid Order ID {TextBox1.Text}</h5>";
                    }
                }
                catch (Exception ex)
                {
                    Label1.Text = $"An error occurred: {ex.Message}";
                }
            }
        }

        private void UpdateOrderStatus(SqlConnection con)
        {
            string updatePaymentQuery = "UPDATE [dbo].[Payment] SET COD_Pay_Status='Received' WHERE Order_Id=@order_id AND Mode='COD'";
            SqlCommand cmd = new SqlCommand(updatePaymentQuery, con);
            cmd.Parameters.AddWithValue("@order_id", TextBox1.Text);

            if (cmd.ExecuteNonQuery() > 0)
            {
                // Update the status in Orders table using Status_Id instead of Status
                string updateStatusQuery = "UPDATE Orders SET Status_Id=@Status_Id WHERE Order_Id=@Order_Id";
                SqlCommand statusCmd = new SqlCommand(updateStatusQuery, con);
                statusCmd.Parameters.AddWithValue("@Status_Id", 2); // Assuming 2 corresponds to 'Delivered'
                statusCmd.Parameters.AddWithValue("@Order_Id", TextBox1.Text);
                statusCmd.ExecuteNonQuery();

                Label1.Text = $"<h5>Status for Order ID {TextBox1.Text} is updated.</h5>";
            }
            else
            {
                Label1.Text = $"<h5>Failed to update status for Order ID {TextBox1.Text}</h5>";
            }
        }
    }
}
