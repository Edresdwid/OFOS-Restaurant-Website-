﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace OFOS
{
    public partial class MyAccount : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] == null || Session["user"].ToString() == "Guest")
            {
                Response.Redirect("FoodItems.aspx");
            }
        }

        protected void Logout1_click(object sender, EventArgs e)
        {
            Session.Abandon();
            Session.Clear();
            Response.Redirect("~/FoodItems.aspx");
        }

        protected void goBack_click(object sender, EventArgs e)
        {
            Response.Redirect("~/FoodItems.aspx");
        }

        protected void AccDetails_DataBound(object sender, EventArgs e)
        {
            if (((DetailsView)sender).CurrentMode == DetailsViewMode.Edit)
            {
                DataRowView row = (DataRowView)((DetailsView)sender).DataItem;
                DropDownList ddlcity = (DropDownList)((DetailsView)sender).FindControl("ddlcity");
                if (ddlcity != null && row != null)
                {
                    ddlcity.SelectedValue = row["City"].ToString();
                }
            }
        }

        protected void AccDetails_ItemUpdating(object sender, DetailsViewUpdateEventArgs e)
        {
            DetailsView dv = (DetailsView)sender;

            // Retrieve each TextBox control and set the UpdateParameters accordingly
            TextBox tbpwd = (TextBox)dv.FindControl("tbpwd");
            TextBox tbemail = (TextBox)dv.FindControl("tbemail");
            TextBox tbcnt = (TextBox)dv.FindControl("tbcnt");
            TextBox tbhouse = (TextBox)dv.FindControl("House_no");
            TextBox tbstreet = (TextBox)dv.FindControl("Street");
            DropDownList ddlcity = (DropDownList)dv.FindControl("ddlcity");

            if (tbpwd != null) sql1.UpdateParameters["Password"].DefaultValue = tbpwd.Text;
            if (tbemail != null) sql1.UpdateParameters["Email"].DefaultValue = tbemail.Text;
            if (tbcnt != null) sql1.UpdateParameters["Contact_no"].DefaultValue = tbcnt.Text;
            if (tbhouse != null) sql1.UpdateParameters["House_no"].DefaultValue = tbhouse.Text;
            if (tbstreet != null) sql1.UpdateParameters["Street"].DefaultValue = tbstreet.Text;
            if (ddlcity != null) sql1.UpdateParameters["City"].DefaultValue = ddlcity.SelectedValue;
        }
    }
}
