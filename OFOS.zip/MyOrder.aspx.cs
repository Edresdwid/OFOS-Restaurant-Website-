﻿using System;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

namespace OFOS
{
    public partial class MyOrder : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] == null)
            {
                Response.Redirect("FoodItems.aspx");
                b.Visible = false;
            }
            else
            {
                b.Visible = true;
                l2.Visible = true;
                l.Text = Session["user"].ToString();
                if (Session["user"].ToString() == "Guest")
                {
                    b.Visible = false;
                    b1.Visible = true;
                }
                else
                {
                    b.Visible = true;
                    b1.Visible = false;
                }
            }

            if (Session["order_id"] == null)
            {
                lbl.Text = "Food cart is empty";
                Button2.Visible = false;
            }
            else
            {
                lbl.Text = "Order Id : " + Session["order_id"].ToString();

                string constr = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\sadsa\Documents\MWM\OSOF\Online-Food-Ordering-System-master\App_Data\ofos.mdf;Integrated Security=True";
                string query = "SELECT SUM(Amount) FROM [dbo].[Order_Details] WHERE Order_Id=@Order_Id";

                using (SqlConnection con = new SqlConnection(constr))
                {
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@Order_Id", Session["order_id"]);

                    try
                    {
                        con.Open();
                        object result = cmd.ExecuteScalar();
                        if (result != null && result != DBNull.Value)
                        {
                            int total = Convert.ToInt32(result);
                            Label1.Text = "Total Amount : ₹ " + total;
                            Session["total"] = total;
                        }
                        else
                        {
                            Label1.Text = "Your order list is empty";
                            Button2.Visible = false;
                        }
                    }
                    catch (Exception ex)
                    {
                        Label1.Text = "An error occurred: " + ex.Message;
                    }
                }
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("FoodItems.aspx");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("Payment.aspx");
        }

        protected void LogOut_click(object sender, EventArgs e)
        {
            Session.Abandon();
            Session.Clear();
            Response.Redirect("FoodItems.aspx");
        }

        protected void gridorder_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            int quantity;
            if (!int.TryParse(e.NewValues["Quantity"].ToString(), out quantity) || quantity < 1 || quantity > 10)
            {
                e.Cancel = true;
                gridorder.Rows[e.RowIndex].Cells[2].Text = e.OldValues["Quantity"].ToString();
                gridorder.DataBind();
            }
        }

        protected void gridorder_RowUpdated(object sender, GridViewUpdatedEventArgs e)
        {
            // Use this event for any actions needed after a successful update
        }
    }
}
