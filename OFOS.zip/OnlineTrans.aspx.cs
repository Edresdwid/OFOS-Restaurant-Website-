﻿using System;
using System.Data.SqlClient;

namespace OFOS
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["order_id"] == null)
            {
                Response.Redirect("FoodItems.aspx");
            }
            else if (Session["pay"] == null)
            {
                Response.Redirect("FoodItems.aspx?First place the order");
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string constr = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\sadsa\Documents\MWM\OSOF\Online-Food-Ordering-System-master\App_Data\ofos.mdf;Integrated Security=True";

            using (SqlConnection con = new SqlConnection(constr))
            {
                string query = "SELECT Balance FROM [dbo].[Accounts] WHERE Acc_No=@acc AND Name=@name AND Acc_pwd=@apwd";
                SqlCommand cmd = new SqlCommand(query, con);

                cmd.Parameters.AddWithValue("@name", Name.Text);
                cmd.Parameters.AddWithValue("@acc", long.Parse(Acc_no.Text));
                cmd.Parameters.AddWithValue("@apwd", Acc_pwd.Text);

                try
                {
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    float balance = 0;
                    if (reader.Read())
                    {
                        balance = float.Parse(reader["Balance"].ToString());
                    }
                    else
                    {
                        // Handle case where account is not found and create it
                        reader.Close();
                        string insertAccount = "INSERT INTO [dbo].[Accounts] (Acc_No, Name, Acc_pwd, Balance) VALUES (@acc, @name, @apwd, 1000)"; // Default balance of 1000 for new accounts
                        SqlCommand insertCmd = new SqlCommand(insertAccount, con);
                        insertCmd.Parameters.AddWithValue("@acc", long.Parse(Acc_no.Text));
                        insertCmd.Parameters.AddWithValue("@name", Name.Text);
                        insertCmd.Parameters.AddWithValue("@apwd", Acc_pwd.Text);

                        insertCmd.ExecuteNonQuery();
                        balance = 1000; // Assume the new account starts with a balance of 1000
                    }
                    reader.Close();

                    int total = (int)Session["total"];

                    float newBalance = balance - total;

                    // Update the balance, even if it goes negative
                    string updateBalance = "UPDATE [dbo].[Accounts] SET Balance=@newBalance WHERE Acc_No=@acc AND Name=@name AND Acc_pwd=@apwd";
                    SqlCommand updateCmd = new SqlCommand(updateBalance, con);
                    updateCmd.Parameters.AddWithValue("@newBalance", newBalance);
                    updateCmd.Parameters.AddWithValue("@acc", long.Parse(Acc_no.Text));
                    updateCmd.Parameters.AddWithValue("@name", Name.Text);
                    updateCmd.Parameters.AddWithValue("@apwd", Acc_pwd.Text);

                    updateCmd.ExecuteNonQuery();

                    // Payment successful
                    status.Text = "Payment successful!";
                    status.Visible = true;
                }
                catch (Exception ex)
                {
                    // Handle exceptions
                    status.Text = "An error occurred: " + ex.Message;
                    status.Visible = true;
                }
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Session["pay"] = "COD";
            Response.Redirect("COD_Delivery.aspx");
        }
    }
}
